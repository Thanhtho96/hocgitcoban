/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bka.binhnk.service;

/**
 *
 * @author Bibi
 */
public class MenuEmployee implements IMenu {

    @Override
    public void showMenu() {
        System.out.println("----Menu-Nhân-Viên----"); 
    
        
        System.out.println("----------------------");}
}
