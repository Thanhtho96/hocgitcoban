/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bka.binhnk.constant;

/**
 *
 * @author Bibi
 */
    public class Constant {

    public static final String UN_CONSTANT  = "admin";
    public static final String PW_CONSTANT  = "admin";

}

