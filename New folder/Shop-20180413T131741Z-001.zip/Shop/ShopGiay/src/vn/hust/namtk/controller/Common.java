/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.hust.namtk.controller;

/**
 *
 * @author QQ
 */
public class Common {
    private static final String USER_NAME_QL = "admin";
    private static final String PASSWORD_QL = "admin";
    private static final String USER_NAME_NV = "nv";
    private static final String PASSWORD_NV = "nv";

    public Common() {
    }

    public static String getUSER_NAME_QL() {
        return USER_NAME_QL;
    }

    public static String getPASSWORD_QL() {
        return PASSWORD_QL;
    }

    public static String getUSER_NAME_NV() {
        return USER_NAME_NV;
    }

    public static String getPASSWORD_NV() {
        return PASSWORD_NV;
    }
    
    
    
}
